package com.carinventory.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.carinventory.dao.CarDao;
import com.carinventory.model.Car;

public class App {
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("Bean.xml");
		Car car = (Car) context.getBean("cr");
		CarDao dao = context.getBean("dao", CarDao.class);

		Scanner scanner = new Scanner(System.in);
		System.out.println("welcome to xyz Car Inventory....");
		System.out.println("Please enter the Command...");
		String command = scanner.next();

		switch (command) {
		case "add":
			System.out.println("Please provide the Car Id here....");
			car.setCarId(scanner.nextInt());

			System.out.println("Please provide the Car Brand name here....");
			car.setBrand(scanner.next());

			System.out.println("Please provide the Car model here....");
			car.setModel(scanner.next());

			System.out.println("Please provide the Car year here....");
			car.setYear(scanner.next());

			System.out.println("Please provide the Car price here....");
			car.setCarPrice(scanner.nextDouble());
			//dao.carInfo();
			dao.storeDetails(car);
			break;

		case "list":
			List list = dao.carInfo();
			System.out.println("Existing cars " + list.size());
			list.forEach(l -> System.out.println(l));
			break;
		case "quit":
			System.out.println("Good Bye");
			break;
		default:
			System.out.println("Please provide the valid command here !!!!");
		}
	}

}
