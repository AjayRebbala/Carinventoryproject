package com.carinventory.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.carinventory.model.Car;

public class CarDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void storeDetails(Car c) {
		jdbcTemplate.update("insert into car values" + "(" + c.getCarId() + ",'" + c.getBrand() + "','" + c.getModel() + "','"
				+ c.getYear() + "','" + c.getCarPrice() + "')");
		System.out.println("car details are stored in database ");
	}

	public List carInfo() {
		return jdbcTemplate.queryForList("select * from inventory.car");
	}
}
